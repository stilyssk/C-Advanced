﻿namespace Car
{
    using System;
    using CarManufacturer;

    /// <summary>
    /// Main program class
    /// </summary>
    public class Car
    {
        /// <summary>
        /// Main function
        /// </summary>
        public static void Main()
        {
            var car = new CarManufacturer.Car()
            {
                Make = "VW",
                Model = "MK3",
                Year = 1992
            };
            Console.WriteLine($"Make:{car.Make}");
            Console.WriteLine($"Model:{car.Model}");
            Console.WriteLine($"Year:{car.Year}");
        }
    }
}
