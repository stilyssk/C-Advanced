﻿namespace CarManufacturer
{
    using System;

    /// <summary>
    /// Class for car
    /// </summary>
    public class Car
    {       
        /// <summary>
        /// make field
        /// </summary>
        private string make;

        /// <summary>
        /// model field
        /// </summary>
        private string model;

        /// <summary>
        /// year field
        /// </summary>
        private int year;

        /// <summary>
        /// Gets or sets the public variable car manufacturer.
        /// </summary>
        public string Make
        {
            get
            {
                return this.make;
            }

            set
            {
                if (value.Length < 2)
                {
                    throw new Exception("Manufacturer name can't be 1 symbol");
                }

                this.make = value;
            }
        }

        /// <summary>
        ///  Gets or sets the public variable car model.
        /// </summary>
        public string Model
        {
            get
            {
                return this.model;
            }

            set
            {
                if (value.Length < 2)
                {
                    throw new Exception("Model name can't be 1 symbol");
                }

                this.model = value;
            }
        }

        /// <summary>
        /// Gets or sets test
        /// </summary>
        public int Year
        {
            get
            {
                return this.year;
            }

            set
            {
                if (value <= 1919)
                {
                    throw new Exception("Car can't be 100 year older");
                }

                this.year = value;
            }
        }
    }
}
