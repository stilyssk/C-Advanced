﻿namespace IteratorsAndComparators
{
    internal class Enumerable<T>
    {
    }
}